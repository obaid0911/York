import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Filter } from 'lucide-react';
import ProductCard from '../components/products/ProductCard';
import ProductFilter from '../components/products/ProductFilter';
import Button from '../components/ui/Button';
import { useProducts } from '../context/ProductContext';

const ProductListing: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const { products, getProductsByCategory, loading } = useProducts();
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [showFilters, setShowFilters] = useState(false);
  
  const filterGroups = [
    {
      name: 'Capacity',
      options: [
        { label: '1 Ton', value: '1-ton' },
        { label: '1.5 Ton', value: '1.5-ton' },
        { label: '2 Ton', value: '2-ton' },
      ],
    },
    {
      name: 'Energy Rating',
      options: [
        { label: '3 Star', value: '3 Star' },
        { label: '4 Star', value: '4 Star' },
        { label: '5 Star', value: '5 Star' },
      ],
    },
    {
      name: 'Features',
      options: [
        { label: 'Inverter', value: 'inverter' },
        { label: 'Wi-Fi Enabled', value: 'wifi' },
        { label: 'Air Purification', value: 'purification' },
        { label: 'Fast Cooling', value: 'fast-cooling' },
      ],
    },
  ];
  
  useEffect(() => {
    if (category) {
      setFilteredProducts(getProductsByCategory(category));
    } else {
      setFilteredProducts(products);
    }
  }, [category, products, getProductsByCategory]);
  
  const handleFilterChange = (filters: Record<string, string[]>) => {
    // This would be more sophisticated in a real app
    let filtered = category ? getProductsByCategory(category) : products;
    
    // Simple filtering example
    if (filters['Energy Rating'] && filters['Energy Rating'].length > 0) {
      filtered = filtered.filter(product => 
        filters['Energy Rating'].includes(product.energyRating)
      );
    }
    
    setFilteredProducts(filtered);
  };
  
  // Get page title based on category
  const getPageTitle = () => {
    if (!category) return 'All Air Conditioners';
    
    const categoryMap: Record<string, string> = {
      '1-ton': '1 Ton Split Air Conditioners',
      '1.5-ton': '1.5 Ton Split Air Conditioners',
      '2-ton': '2 Ton Split Air Conditioners',
    };
    
    return categoryMap[category] || 'Products';
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{getPageTitle()}</h1>
          <p className="text-gray-600 max-w-3xl">
            Browse our selection of premium YORK air conditioners. All models come with warranty and professional installation services.
          </p>
        </div>
        
        {/* Mobile filter button */}
        <div className="md:hidden mb-6">
          <Button
            onClick={() => setShowFilters(!showFilters)}
            variant="outline"
            leftIcon={<Filter className="h-4 w-4" />}
            fullWidth
          >
            {showFilters ? 'Hide Filters' : 'Show Filters'}
          </Button>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - mobile collapsible, desktop always visible */}
          <div className={`md:w-1/4 lg:w-1/5 ${showFilters ? 'block' : 'hidden md:block'}`}>
            <ProductFilter filterGroups={filterGroups} onFilterChange={handleFilterChange} />
          </div>
          
          {/* Product Grid */}
          <div className="flex-1">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-700"></div>
              </div>
            ) : filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg p-8 text-center shadow-sm">
                <h3 className="text-xl font-medium text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your filters or browse all categories.
                </p>
                <Button onClick={() => setFilteredProducts(products)}>
                  View All Products
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductListing;