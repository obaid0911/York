import React from 'react';
import { Link } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';
import Button from '../components/ui/Button';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full text-center">
        <div className="mb-8">
          <div className="flex justify-center">
            <div className="relative">
              <div className="text-9xl font-bold text-blue-700 opacity-20">404</div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-4xl font-bold text-blue-700">404</div>
              </div>
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mt-4">Page Not Found</h1>
          <p className="text-gray-600 mt-2">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Link to="/">
            <Button leftIcon={<Home className="h-5 w-5" />}>
              Back to Home
            </Button>
          </Link>
          <button onClick={() => window.history.back()}>
            <Button variant="outline" leftIcon={<ArrowLeft className="h-5 w-5" />}>
              Go Back
            </Button>
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;