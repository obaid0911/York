import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Star, Shield, RefreshCw, Zap, Send } from 'lucide-react';
import IntroAnimation from '../components/home/IntroAnimation';
import Button from '../components/ui/Button';
import { useProducts } from '../context/ProductContext';
import ProductCard from '../components/products/ProductCard';

const Home: React.FC = () => {
  const { featuredProducts, loading } = useProducts();

  return (
    <>
      <IntroAnimation />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-blue-900 to-blue-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center"></div>
        </div>

        <div className="container mx-auto px-4 md:px-6 py-16 md:py-24 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Authorized Distributor of YORK Air Conditioners in Pakistan
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Experience premium cooling with American engineering excellence
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                size="lg"
                leftIcon={<Zap className="h-5 w-5" />}
                onClick={() => {
                  const productsSection = document.getElementById('featured-products');
                  productsSection?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Explore Products
              </Button>
              <Link to="/contact">
                <Button
                  variant="outline"
                  size="lg"
                  leftIcon={<Send className="h-5 w-5" />}
                  className="bg-transparent border-white text-white hover:bg-white hover:bg-opacity-10"
                >
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Products</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Find the perfect air conditioning solution for your space
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Link
              to="/products/1-ton"
              className="relative group overflow-hidden rounded-xl shadow-lg transition-transform hover:-translate-y-2"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900 to-transparent opacity-70 z-10"></div>
              <img
                src="https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="1 Ton AC"
                className="w-full h-72 object-cover transform group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 z-20">
                <h3 className="text-2xl font-bold text-white mb-2">1 Ton Split AC</h3>
                <p className="text-blue-100 mb-4">Perfect for small rooms up to 120 sq. ft.</p>
                <div className="flex items-center text-white">
                  <span className="mr-2">View Products</span>
                  <ChevronRight className="h-5 w-5 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>

            <Link
              to="/products/1.5-ton"
              className="relative group overflow-hidden rounded-xl shadow-lg transition-transform hover:-translate-y-2"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900 to-transparent opacity-70 z-10"></div>
              <img
                src="https://images.pexels.com/photos/5563488/pexels-photo-5563488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="1.5 Ton AC"
                className="w-full h-72 object-cover transform group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 z-20">
                <h3 className="text-2xl font-bold text-white mb-2">1.5 Ton Split AC</h3>
                <p className="text-blue-100 mb-4">Ideal for medium rooms up to 180 sq. ft.</p>
                <div className="flex items-center text-white">
                  <span className="mr-2">View Products</span>
                  <ChevronRight className="h-5 w-5 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>

            <Link
              to="/products/2-ton"
              className="relative group overflow-hidden rounded-xl shadow-lg transition-transform hover:-translate-y-2"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900 to-transparent opacity-70 z-10"></div>
              <img
                src="https://images.pexels.com/photos/5563496/pexels-photo-5563496.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="2 Ton AC"
                className="w-full h-72 object-cover transform group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 z-20">
                <h3 className="text-2xl font-bold text-white mb-2">2 Ton Split AC</h3>
                <p className="text-blue-100 mb-4">Perfect for large rooms up to 240 sq. ft.</p>
                <div className="flex items-center text-white">
                  <span className="mr-2">View Products</span>
                  <ChevronRight className="h-5 w-5 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section id="featured-products" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Featured Products</h2>
              <p className="text-xl text-gray-600 max-w-2xl">
                Our most popular air conditioning solutions
              </p>
            </div>
            <Link to="/products" className="mt-4 md:mt-0">
              <Button
                variant="outline"
                rightIcon={<ChevronRight className="h-5 w-5" />}
              >
                View All Products
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-700"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose YORK</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Industry-leading technology and exceptional service
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-blue-50 p-6 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Premium Quality</h3>
              <p className="text-gray-600">
                American engineering excellence with top-tier components for lasting performance
              </p>
            </div>

            <div className="bg-blue-50 p-6 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Zap className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Energy Efficient</h3>
              <p className="text-gray-600">
                Advanced inverter technology that reduces power consumption and lowers bills
              </p>
            </div>

            <div className="bg-blue-50 p-6 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Warranty Protection</h3>
              <p className="text-gray-600">
                Comprehensive warranty with authorized service and genuine parts
              </p>
            </div>

            <div className="bg-blue-50 p-6 rounded-xl text-center hover:shadow-lg transition-shadow">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">After-Sales Support</h3>
              <p className="text-gray-600">
                Dedicated customer service team and rapid technical assistance
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Experience YORK?</h2>
            <p className="text-xl mb-8">
              Contact us today for product information, pricing, or to schedule an installation consultation
            </p>
            <Link to="/contact">
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-blue-700"
              >
                Contact Us Now
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;