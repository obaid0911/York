import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Truck, ShieldCheck, ArrowLeft, ThermometerSnowflake, Wind, Zap } from 'lucide-react';
import Button from '../components/ui/Button';
import ProductGallery from '../components/products/ProductGallery';
import { useProducts } from '../context/ProductContext';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getProductById, loading } = useProducts();
  const [activeTab, setActiveTab] = useState<'description' | 'specifications' | 'features'>('description');
  const [showInquiryForm, setShowInquiryForm] = useState(false);
  const [inquiryFormData, setInquiryFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const product = getProductById(id || '');

  const handleInquiryFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setInquiryFormData({
      ...inquiryFormData,
      [name]: value,
    });
  };

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would send the inquiry data to a server
    alert('Your inquiry has been submitted. Our team will contact you shortly.');
    setShowInquiryForm(false);
    setInquiryFormData({
      name: '',
      email: '',
      phone: '',
      message: '',
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-24">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-700"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="bg-white rounded-lg p-8 text-center shadow-sm">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h2>
            <p className="text-gray-600 mb-6">
              The product you're looking for doesn't exist or has been removed.
            </p>
            <Link to="/products">
              <Button leftIcon={<ArrowLeft className="h-5 w-5" />}>
                Back to Products
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <ol className="flex text-sm text-gray-600">
            <li className="flex items-center">
              <Link to="/" className="hover:text-blue-700">Home</Link>
              <span className="mx-2">/</span>
            </li>
            <li className="flex items-center">
              <Link to="/products" className="hover:text-blue-700">Products</Link>
              <span className="mx-2">/</span>
            </li>
            <li className="flex items-center">
              <Link to={`/products/${product.category}`} className="hover:text-blue-700">
                {product.category} ACs
              </Link>
              <span className="mx-2">/</span>
            </li>
            <li className="text-gray-900 font-medium">{product.name}</li>
          </ol>
        </nav>

        {/* Product Section */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-6 md:p-8">
            <div>
              <ProductGallery images={product.images} productName={product.name} />
            </div>
            
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
              <p className="text-gray-600 mb-6">{product.shortDescription}</p>
              
              <div className="flex items-center mb-6">
                <div className="mr-6">
                  <span className="text-2xl font-bold text-gray-900">{product.price}</span>
                  {product.discountedPrice && (
                    <span className="text-sm text-gray-500 line-through ml-2">
                      {product.discountedPrice}
                    </span>
                  )}
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  product.stock === 'In Stock' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {product.stock}
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center">
                  <ThermometerSnowflake className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">{product.capacity}</span>
                </div>
                <div className="flex items-center">
                  <Wind className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">Air Flow: {product.specifications.airflow}</span>
                </div>
                <div className="flex items-center">
                  <Zap className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">Energy: {product.energyRating}</span>
                </div>
                <div className="flex items-center">
                  <ShieldCheck className="h-5 w-5 text-blue-600 mr-2" />
                  <span className="text-gray-700">2 Year Warranty</span>
                </div>
              </div>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-start">
                  <Truck className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-gray-900">Free Delivery</h4>
                    <p className="text-sm text-gray-600">Delivery within Karachi in 2-3 business days</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <ShieldCheck className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-gray-900">Authorized Distributor</h4>
                    <p className="text-sm text-gray-600">Official YORK warranty and after-sales support</p>
                  </div>
                </div>
              </div>
              
              <div className="space-x-4">
                <Button size="lg" onClick={() => setShowInquiryForm(true)}>
                  Request Quote
                </Button>
                <Link to="/contact">
                  <Button variant="outline" size="lg">
                    Contact Support
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Product Details Tabs */}
          <div className="border-t border-gray-200">
            <div className="flex border-b border-gray-200">
              <button
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'description'
                    ? 'text-blue-700 border-b-2 border-blue-700'
                    : 'text-gray-600 hover:text-blue-700'
                }`}
                onClick={() => setActiveTab('description')}
              >
                Description
              </button>
              <button
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'specifications'
                    ? 'text-blue-700 border-b-2 border-blue-700'
                    : 'text-gray-600 hover:text-blue-700'
                }`}
                onClick={() => setActiveTab('specifications')}
              >
                Specifications
              </button>
              <button
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'features'
                    ? 'text-blue-700 border-b-2 border-blue-700'
                    : 'text-gray-600 hover:text-blue-700'
                }`}
                onClick={() => setActiveTab('features')}
              >
                Features
              </button>
            </div>
            
            <div className="p-6 md:p-8">
              {activeTab === 'description' && (
                <div className="prose max-w-none">
                  <p className="text-gray-700">{product.description}</p>
                </div>
              )}
              
              {activeTab === 'specifications' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Technical Specifications</h3>
                    <table className="w-full text-sm">
                      <tbody>
                        {Object.entries(product.specifications).map(([key, value]) => (
                          <tr key={key} className="border-b border-gray-200">
                            <td className="py-3 text-gray-700 font-medium capitalize">{key.replace(/([A-Z])/g, ' $1')}</td>
                            <td className="py-3 text-gray-900">{value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Dimensions & Installation</h3>
                    <table className="w-full text-sm">
                      <tbody>
                        <tr className="border-b border-gray-200">
                          <td className="py-3 text-gray-700 font-medium">Indoor Unit (WxHxD)</td>
                          <td className="py-3 text-gray-900">{product.specifications.dimensions}</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="py-3 text-gray-700 font-medium">Refrigerant Type</td>
                          <td className="py-3 text-gray-900">
                            {product.features.find(f => f.includes('R-'))?.split('Refrigerant')[0] || 'R-32'}
                          </td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="py-3 text-gray-700 font-medium">Standard Installation</td>
                          <td className="py-3 text-gray-900">Included with purchase</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td className="py-3 text-gray-700 font-medium">Pipe Length</td>
                          <td className="py-3 text-gray-900">Up to 15 feet included</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              
              {activeTab === 'features' && (
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Key Features</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-y-3 gap-x-6">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <svg className="h-5 w-5 text-blue-600 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Inquiry Form Modal */}
        {showInquiryForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold text-gray-900">Request a Quote</h3>
                  <button
                    className="text-gray-500 hover:text-gray-700"
                    onClick={() => setShowInquiryForm(false)}
                  >
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                
                <form onSubmit={handleInquirySubmit}>
                  <div className="mb-4">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={inquiryFormData.name}
                      onChange={handleInquiryFormChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={inquiryFormData.email}
                      onChange={handleInquiryFormChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={inquiryFormData.phone}
                      onChange={handleInquiryFormChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Message (Optional)
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={inquiryFormData.message}
                      onChange={handleInquiryFormChange}
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    ></textarea>
                  </div>
                  
                  <div className="flex space-x-4">
                    <Button type="submit" fullWidth>
                      Submit Inquiry
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;