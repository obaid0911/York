export interface Product {
  id: string;
  name: string;
  category: string;
  capacity: string;
  shortDescription: string;
  description: string;
  features: string[];
  specifications: {
    cooling: string;
    powerConsumption: string;
    energyRating: string;
    airflow: string;
    noise: string;
    dimensions: string;
    [key: string]: string;
  };
  price: string;
  discountedPrice?: string;
  image: string;
  images: string[];
  energyRating: string;
  featured: boolean;
  stock: string;
}