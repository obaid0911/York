import React from 'react';
import { Snowflake } from 'lucide-react';

interface YorkLogoProps {
  className?: string;
}

const YorkLogo: React.FC<YorkLogoProps> = ({ className = 'h-8 w-8' }) => {
  return (
    <div className={`flex items-center justify-center bg-blue-700 rounded-full ${className}`}>
      <Snowflake className="text-white h-2/3 w-2/3" />
    </div>
  );
};

export default YorkLogo;