import React, { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';

const IntroAnimation: React.FC = () => {
  const [animationStage, setAnimationStage] = useState<number>(0);
  const [showSkip, setShowSkip] = useState<boolean>(true);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  // Check if animation has been seen before
  useEffect(() => {
    const hasSeenAnimation = localStorage.getItem('yorkHasSeenIntro');
    if (hasSeenAnimation) {
      setIsCompleted(true);
    }
  }, []);

  // Progress through animation stages
  useEffect(() => {
    if (isCompleted) return;

    const timer = setTimeout(() => {
      if (animationStage < 3) {
        setAnimationStage(animationStage + 1);
      } else {
        completeAnimation();
      }
    }, animationStage === 0 ? 1000 : 2500);

    return () => clearTimeout(timer);
  }, [animationStage, isCompleted]);

  const completeAnimation = () => {
    setIsCompleted(true);
    localStorage.setItem('yorkHasSeenIntro', 'true');
  };

  const skipAnimation = () => {
    completeAnimation();
  };

  if (isCompleted) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden">
      {/* Hot Scene */}
      <div
        className={`absolute inset-0 bg-gradient-to-b from-yellow-500 via-orange-500 to-red-500 transition-opacity duration-1000 ease-in-out ${
          animationStage === 0 ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <div className="w-32 h-32 rounded-full bg-yellow-300 animate-pulse mb-8" />
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-4 text-center">
            When Heat Surrounds You...
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            {[...Array(6)].map((_, i) => (
              <div 
                key={i} 
                className="w-16 h-16 bg-red-400 rounded-full opacity-75 animate-float"
                style={{ 
                  animationDelay: `${i * 0.2}s`,
                  transform: `translateY(${Math.sin(i) * 10}px)`
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Transition Scene */}
      <div
        className={`absolute inset-0 bg-gradient-to-b from-orange-400 via-blue-300 to-blue-500 transition-opacity duration-1000 ease-in-out ${
          animationStage === 1 ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-64 h-64">
            <div className="absolute inset-0 bg-red-500 rounded-full animate-pulse opacity-50" />
            <div className="absolute inset-4 bg-blue-300 rounded-full animate-pulse opacity-80" />
            <h2 className="absolute inset-0 flex items-center justify-center text-4xl font-bold text-white">
              YORK
            </h2>
          </div>
        </div>
      </div>

      {/* Cool Scene */}
      <div
        className={`absolute inset-0 bg-gradient-to-b from-blue-400 via-blue-300 to-blue-100 transition-opacity duration-1000 ease-in-out ${
          animationStage === 2 ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="absolute inset-0 flex flex-col items-center justify-center text-blue-900">
          <div className="w-40 h-40 relative mb-8">
            <div className="absolute inset-0 rounded-full border-8 border-blue-200 animate-spin-slow" />
            <div className="absolute inset-8 flex items-center justify-center bg-white rounded-full shadow-lg">
              <span className="text-3xl font-bold text-blue-700">YORK</span>
            </div>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-4 text-center">
            Experience Perfect Cooling
          </h2>
          <div className="flex flex-wrap justify-center gap-6">
            {[...Array(8)].map((_, i) => (
              <div 
                key={i} 
                className="w-8 h-8 bg-blue-200 rounded-sm opacity-75 animate-float-slow rotate-45"
                style={{ 
                  animationDelay: `${i * 0.3}s`,
                  transform: `translateY(${Math.sin(i) * 15}px) rotate(45deg)`
                }}
              />
            ))}
          </div>
        </div>
      </div>
      
      {/* Final Scene / Call to Action */}
      <div
        className={`absolute inset-0 bg-white transition-opacity duration-1000 ease-in-out ${
          animationStage === 3 ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
          <YorkLogo className="h-24 w-24 mb-6 animate-float" />
          <h1 className="text-4xl md:text-6xl font-bold text-blue-900 mb-4 text-center">
            YORK Air Conditioners
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 text-center max-w-2xl">
            Authorized Distributor in Pakistan
          </p>
          <button
            onClick={completeAnimation}
            className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-medium text-white bg-blue-700 rounded-md overflow-hidden transition-all duration-300 ease-in-out hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <span>Explore Products</span>
            <ChevronDown className="ml-2 h-5 w-5 group-hover:animate-bounce" />
          </button>
        </div>
      </div>

      {/* Skip Button */}
      {showSkip && (
        <button
          onClick={skipAnimation}
          className="absolute top-4 right-4 px-4 py-2 text-sm text-white bg-black bg-opacity-30 rounded-md hover:bg-opacity-50 transition-colors z-50"
        >
          Skip
        </button>
      )}
    </div>
  );
};

// Helper component for the York logo
const YorkLogo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={`relative ${className}`}>
      <div className="absolute inset-0 bg-blue-500 rounded-full animate-pulse" />
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-3xl font-bold text-white">YORK</span>
      </div>
    </div>
  );
};

export default IntroAnimation;