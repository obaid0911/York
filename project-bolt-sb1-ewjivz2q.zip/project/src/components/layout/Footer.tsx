import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';
import YorkLogo from '../common/YorkLogo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <YorkLogo className="h-10 w-auto text-white" />
              <span className="ml-2 text-xl font-bold">YORK.PK</span>
            </div>
            <p className="text-gray-400 mb-4">
              Authorized distributor of York Air Conditioners in Pakistan.
              Providing premium cooling solutions for your home and office.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-400 hover:text-white transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Products</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/products/1-ton" className="text-gray-400 hover:text-white transition-colors">
                  1 Ton Split AC
                </Link>
              </li>
              <li>
                <Link to="/products/1.5-ton" className="text-gray-400 hover:text-white transition-colors">
                  1.5 Ton Split AC
                </Link>
              </li>
              <li>
                <Link to="/products/2-ton" className="text-gray-400 hover:text-white transition-colors">
                  2 Ton Split AC
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Phone className="h-5 w-5 mr-2 text-blue-500" />
                <span className="text-gray-400">+92 300 1234567</span>
              </li>
              <li className="flex items-start">
                <Mail className="h-5 w-5 mr-2 text-blue-500" />
                <span className="text-gray-400">info@york.pk</span>
              </li>
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 text-blue-500" />
                <span className="text-gray-400">
                  Office #123, Business Plaza, Shahrah-e-Faisal, Karachi, Pakistan
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} York Pakistan. All rights reserved.</p>
          <p className="mt-2">
            Designed and developed by <span className="text-blue-500">YorkTech</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;