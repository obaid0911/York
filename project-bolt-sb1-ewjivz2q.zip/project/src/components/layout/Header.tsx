import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, Snowflake } from 'lucide-react';
import YorkLogo from '../common/YorkLogo';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <YorkLogo className="h-10 w-auto" />
            <div className="ml-2">
              <span className="text-blue-800 font-bold text-xl">YORK</span>
              <span className="block text-xs text-gray-600">Authorized Distributor - Pakistan</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link
              to="/"
              className={`text-sm font-medium transition-colors ${
                location.pathname === '/'
                  ? 'text-blue-700'
                  : isScrolled
                  ? 'text-gray-800 hover:text-blue-700'
                  : 'text-white hover:text-blue-100'
              }`}
            >
              Home
            </Link>
            <div className="relative group">
              <button
                className={`flex items-center text-sm font-medium transition-colors ${
                  location.pathname.includes('/products')
                    ? 'text-blue-700'
                    : isScrolled
                    ? 'text-gray-800 hover:text-blue-700'
                    : 'text-white hover:text-blue-100'
                }`}
              >
                Products <ChevronDown className="h-4 w-4 ml-1" />
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform -translate-y-2 group-hover:translate-y-0">
                <Link
                  to="/products/1-ton"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-md"
                >
                  1 Ton Split AC
                </Link>
                <Link
                  to="/products/1.5-ton"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-md"
                >
                  1.5 Ton Split AC
                </Link>
                <Link
                  to="/products/2-ton"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-md"
                >
                  2 Ton Split AC
                </Link>
              </div>
            </div>
            <Link
              to="/contact"
              className={`text-sm font-medium transition-colors ${
                location.pathname === '/contact'
                  ? 'text-blue-700'
                  : isScrolled
                  ? 'text-gray-800 hover:text-blue-700'
                  : 'text-white hover:text-blue-100'
              }`}
            >
              Contact
            </Link>
          </nav>

          {/* Mobile menu button */}
          <button
            className="lg:hidden text-gray-800 hover:text-blue-700 focus:outline-none"
            onClick={toggleMenu}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        <div
          className={`lg:hidden ${
            isOpen ? 'block' : 'hidden'
          } bg-white mt-4 py-4 px-4 rounded-lg shadow-md`}
        >
          <Link
            to="/"
            className="block py-2 text-gray-800 hover:text-blue-700"
          >
            Home
          </Link>
          <div className="py-2">
            <p className="text-gray-800 font-medium mb-2">Products</p>
            <Link
              to="/products/1-ton"
              className="block py-2 pl-4 text-gray-700 hover:text-blue-700"
            >
              1 Ton Split AC
            </Link>
            <Link
              to="/products/1.5-ton"
              className="block py-2 pl-4 text-gray-700 hover:text-blue-700"
            >
              1.5 Ton Split AC
            </Link>
            <Link
              to="/products/2-ton"
              className="block py-2 pl-4 text-gray-700 hover:text-blue-700"
            >
              2 Ton Split AC
            </Link>
          </div>
          <Link
            to="/contact"
            className="block py-2 text-gray-800 hover:text-blue-700"
          >
            Contact
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;