import React, { useState } from 'react';
import { Filter, ChevronDown, ChevronUp } from 'lucide-react';

interface FilterOption {
  label: string;
  value: string;
}

interface FilterGroup {
  name: string;
  options: FilterOption[];
}

interface ProductFilterProps {
  filterGroups: FilterGroup[];
  onFilterChange: (filters: Record<string, string[]>) => void;
}

const ProductFilter: React.FC<ProductFilterProps> = ({ filterGroups, onFilterChange }) => {
  const [filters, setFilters] = useState<Record<string, string[]>>({});
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});

  const toggleGroup = (groupName: string) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [groupName]: !prev[groupName],
    }));
  };

  const handleFilterChange = (group: string, value: string) => {
    setFilters((prevFilters) => {
      const groupFilters = prevFilters[group] || [];
      const newGroupFilters = groupFilters.includes(value)
        ? groupFilters.filter((v) => v !== value)
        : [...groupFilters, value];

      const newFilters = {
        ...prevFilters,
        [group]: newGroupFilters,
      };

      onFilterChange(newFilters);
      return newFilters;
    });
  };

  return (
    <div className="bg-white rounded-lg shadow p-5">
      <div className="flex items-center mb-5">
        <Filter className="h-5 w-5 text-blue-700 mr-2" />
        <h3 className="text-lg font-medium text-gray-900">Filters</h3>
      </div>

      <div className="space-y-5">
        {filterGroups.map((group) => (
          <div key={group.name} className="border-b border-gray-200 pb-5 last:border-0 last:pb-0">
            <button
              className="flex items-center justify-between w-full text-left"
              onClick={() => toggleGroup(group.name)}
            >
              <span className="text-sm font-medium text-gray-700">{group.name}</span>
              {expandedGroups[group.name] ? (
                <ChevronUp className="h-4 w-4 text-gray-500" />
              ) : (
                <ChevronDown className="h-4 w-4 text-gray-500" />
              )}
            </button>

            <div className={`mt-2 space-y-1 ${expandedGroups[group.name] ? 'block' : 'hidden'}`}>
              {group.options.map((option) => (
                <label key={option.value} className="flex items-center">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    checked={(filters[group.name] || []).includes(option.value)}
                    onChange={() => handleFilterChange(group.name, option.value)}
                  />
                  <span className="ml-2 text-sm text-gray-600">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductFilter;