import React from 'react';
import { Link } from 'react-router-dom';
import { Snowflake, ThermometerSnowflake, Wind, Star } from 'lucide-react';
import { Product } from '../../types/product';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="group bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      <div className="relative overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-64 object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
        />
        {product.featured && (
          <div className="absolute top-4 right-4 bg-yellow-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
            <Star className="h-3 w-3 mr-1" /> Featured
          </div>
        )}
      </div>
      
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex-grow">
          <div className="flex items-center mb-1">
            <h3 className="text-xl font-semibold text-gray-900 flex-grow">{product.name}</h3>
            <Snowflake className="h-5 w-5 text-blue-500" />
          </div>
          
          <p className="text-sm text-gray-600 mb-4">{product.shortDescription}</p>
          
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="flex items-center text-sm text-gray-700">
              <ThermometerSnowflake className="h-4 w-4 mr-2 text-blue-500" />
              <span>{product.capacity}</span>
            </div>
            <div className="flex items-center text-sm text-gray-700">
              <Wind className="h-4 w-4 mr-2 text-blue-500" />
              <span>{product.energyRating}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4">
          <div className="text-gray-900 font-bold">
            <span className="text-lg">{product.price}</span>
            {product.discountedPrice && (
              <span className="text-sm text-gray-500 line-through ml-2">
                {product.discountedPrice}
              </span>
            )}
          </div>
          
          <Link 
            to={`/product/${product.id}`}
            className="inline-flex items-center font-medium text-blue-700 hover:text-blue-900 transition-colors"
          >
            View details
            <svg 
              className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;