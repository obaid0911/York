import { Product } from '../types/product';

export const productData: Product[] = [
  {
    id: '1',
    name: 'YORK 1 Ton Inverter Split AC',
    category: '1-ton',
    capacity: '1 Ton (12000 BTU)',
    shortDescription: 'Energy-efficient cooling with innovative YORK technology',
    description: 'Experience superior cooling with YORK\'s 1 Ton Split AC featuring advanced inverter technology. This model is designed to provide optimal cooling while consuming less power, making it perfect for small to medium-sized rooms. The AC comes with a range of features including a sleep mode, auto restart, and a comprehensive filtration system to ensure clean, cool air throughout your space.',
    features: [
      'Energy Efficient Inverter Technology',
      'Low Noise Operation',
      'Anti-bacterial Filter',
      'Sleep Mode',
      'Auto Restart',
      'R-410A Refrigerant'
    ],
    specifications: {
      cooling: '12000 BTU/hr',
      powerConsumption: '1100W',
      energyRating: '4 Star',
      airflow: '560 m³/h',
      noise: '29 dB(A)',
      dimensions: '900 x 290 x 215 mm'
    },
    price: 'Rs. 85,000',
    discountedPrice: 'Rs. 95,000',
    image: 'https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    images: [
      'https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563461/pexels-photo-5563461.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563513/pexels-photo-5563513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    energyRating: '4 Star',
    featured: true,
    stock: 'In Stock'
  },
  {
    id: '2',
    name: 'YORK 1 Ton Fixed Speed Split AC',
    category: '1-ton',
    capacity: '1 Ton (12000 BTU)',
    shortDescription: 'Reliable cooling solution for small to medium rooms',
    description: 'The YORK 1 Ton Fixed Speed Split AC offers reliable cooling for smaller spaces at an affordable price point. This unit features a robust cooling system with YORK\'s signature quality and durability. The AC includes essential features like a dust filter, LED display, and remote control for convenient operation.',
    features: [
      'Fixed Speed Compressor',
      'Dust Filter',
      'LED Display',
      'Remote Control',
      'Auto Restart Feature',
      'R-32 Refrigerant'
    ],
    specifications: {
      cooling: '12000 BTU/hr',
      powerConsumption: '1200W',
      energyRating: '3 Star',
      airflow: '520 m³/h',
      noise: '32 dB(A)',
      dimensions: '880 x 275 x 205 mm'
    },
    price: 'Rs. 75,000',
    image: 'https://images.pexels.com/photos/5563452/pexels-photo-5563452.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    images: [
      'https://images.pexels.com/photos/5563452/pexels-photo-5563452.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563469/pexels-photo-5563469.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    energyRating: '3 Star',
    featured: false,
    stock: 'In Stock'
  },
  {
    id: '3',
    name: 'YORK 1.5 Ton Smart Inverter AC',
    category: '1.5-ton',
    capacity: '1.5 Ton (18000 BTU)',
    shortDescription: 'Smart cooling with Wi-Fi control and premium features',
    description: 'The YORK 1.5 Ton Smart Inverter AC combines cutting-edge cooling technology with smart home integration. Control your AC from anywhere using the YORK Smart App, set schedules, and monitor energy usage. This premium model features advanced air purification, quiet operation, and optimized energy efficiency for medium to large rooms.',
    features: [
      'Wi-Fi Enabled Smart Control',
      'Voice Assistant Compatible',
      'Multi-stage Air Purification',
      'Ultra Quiet Operation',
      'Eco Mode',
      'Fast Cooling Technology',
      'R-410A Refrigerant'
    ],
    specifications: {
      cooling: '18000 BTU/hr',
      powerConsumption: '1550W',
      energyRating: '5 Star',
      airflow: '680 m³/h',
      noise: '26 dB(A)',
      dimensions: '950 x 310 x 230 mm'
    },
    price: 'Rs. 120,000',
    image: 'https://images.pexels.com/photos/5563488/pexels-photo-5563488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    images: [
      'https://images.pexels.com/photos/5563488/pexels-photo-5563488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563508/pexels-photo-5563508.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563548/pexels-photo-5563548.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    energyRating: '5 Star',
    featured: true,
    stock: 'In Stock'
  },
  {
    id: '4',
    name: 'YORK 1.5 Ton Standard Inverter AC',
    category: '1.5-ton',
    capacity: '1.5 Ton (18000 BTU)',
    shortDescription: 'Efficient cooling with improved energy savings',
    description: 'The YORK 1.5 Ton Standard Inverter AC provides reliable cooling with enhanced energy efficiency. Perfect for medium-sized rooms, this AC adjusts its cooling capacity based on room temperature, resulting in consistent comfort and reduced power consumption. Features include a multi-filter system, sleep mode, and auto-diagnostic function.',
    features: [
      'DC Inverter Technology',
      'Multi-Filter System',
      'Sleep Mode',
      'Auto Diagnostic',
      'Golden Fin Condenser',
      'R-32 Refrigerant'
    ],
    specifications: {
      cooling: '18000 BTU/hr',
      powerConsumption: '1600W',
      energyRating: '4 Star',
      airflow: '650 m³/h',
      noise: '28 dB(A)',
      dimensions: '940 x 300 x 220 mm'
    },
    price: 'Rs. 105,000',
    image: 'https://images.pexels.com/photos/5563476/pexels-photo-5563476.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    images: [
      'https://images.pexels.com/photos/5563476/pexels-photo-5563476.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563511/pexels-photo-5563511.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    energyRating: '4 Star',
    featured: false,
    stock: 'In Stock'
  },
  {
    id: '5',
    name: 'YORK 2 Ton Premium Inverter AC',
    category: '2-ton',
    capacity: '2 Ton (24000 BTU)',
    shortDescription: 'Premium cooling solution for large spaces with advanced features',
    description: 'The YORK 2 Ton Premium Inverter AC is designed for large rooms and open spaces, offering powerful cooling with unmatched efficiency. This flagship model features YORK\'s latest inverter technology, premium air purification system, and whisper-quiet operation. Perfect for living rooms, large bedrooms, or small offices.',
    features: [
      'Advanced Inverter Technology',
      'Premium Air Purification System',
      'Ultra Low Noise Technology',
      'Rapid Cooling',
      'Smart Diagnosis',
      'Auto Clean Function',
      'R-410A Refrigerant'
    ],
    specifications: {
      cooling: '24000 BTU/hr',
      powerConsumption: '2000W',
      energyRating: '5 Star',
      airflow: '850 m³/h',
      noise: '27 dB(A)',
      dimensions: '1100 x 330 x 245 mm'
    },
    price: 'Rs. 145,000',
    image: 'https://images.pexels.com/photos/5563496/pexels-photo-5563496.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    images: [
      'https://images.pexels.com/photos/5563496/pexels-photo-5563496.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563525/pexels-photo-5563525.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563456/pexels-photo-5563456.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    energyRating: '5 Star',
    featured: true,
    stock: 'In Stock'
  },
  {
    id: '6',
    name: 'YORK 2 Ton Standard Split AC',
    category: '2-ton',
    capacity: '2 Ton (24000 BTU)',
    shortDescription: 'Powerful cooling for larger rooms with essential features',
    description: 'The YORK 2 Ton Standard Split AC provides powerful cooling for larger rooms without premium features. This unit delivers reliable performance with YORK\'s quality engineering at a more accessible price point. Features include a standard filtration system, remote control operation, and auto restart capability.',
    features: [
      'Fixed Speed Compressor',
      'Standard Filtration',
      'Remote Control',
      'Auto Restart',
      'Sleep Mode',
      'R-32 Refrigerant'
    ],
    specifications: {
      cooling: '24000 BTU/hr',
      powerConsumption: '2200W',
      energyRating: '3 Star',
      airflow: '800 m³/h',
      noise: '35 dB(A)',
      dimensions: '1080 x 320 x 235 mm'
    },
    price: 'Rs. 125,000',
    image: 'https://images.pexels.com/photos/5563463/pexels-photo-5563463.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    images: [
      'https://images.pexels.com/photos/5563463/pexels-photo-5563463.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5563490/pexels-photo-5563490.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    energyRating: '3 Star',
    featured: false,
    stock: 'Limited Stock'
  }
];